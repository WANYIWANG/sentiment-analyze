var googleDocURL = 'https://docs.google.com/spreadsheets/d/1ptFJutaAaSspjjZC0CVPzs53v5Gpqt7HFytXPWvIU5c/edit#gid=0';
